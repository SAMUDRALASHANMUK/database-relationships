package com.marketsimplified.DatabaseDesign;

import java.sql.*;

public class DatabaseDesign 
{

	    	   	

    
    public static void main(String[] args) throws SQLException, ClassNotFoundException 
    {

	    String url = "jdbc:mysql://localhost:3306/Relationship";
        String username = "root";
        String password = "Samudralashanmuk123#";
        Class.forName("com.mysql.jdbc.Driver");
    	Connection conn = DriverManager.getConnection(url, username, password); 
       
        try {
        	    
            Statement stmt = conn.createStatement(); 
            
            // one-to-one relationship
            String createEmployeeTable = "CREATE TABLE Employee (" +
                "id INT AUTO_INCREMENT," +
                "name VARCHAR(50) NOT NULL," +
                "email VARCHAR(50) NOT NULL UNIQUE," +
                "PRIMARY KEY (id)" +
            ")";
            
            stmt.executeUpdate(createEmployeeTable);
            
            String createAddressTable = "CREATE TABLE Address (" +
                "id INT AUTO_INCREMENT," +
                "street VARCHAR(50) NOT NULL," +
                "city VARCHAR(50) NOT NULL," +
                "state VARCHAR(50) NOT NULL," +
                "zip VARCHAR(10) NOT NULL," +
                "employee_id INT NOT NULL UNIQUE," +
                "PRIMARY KEY (id)," +
                "FOREIGN KEY (employee_id) REFERENCES Employee(id)" +
            ")";
            stmt.executeUpdate(createAddressTable);
            
            // one-to-many relationship
            String createCustomerTable = "CREATE TABLE Customer (" +
                "id INT AUTO_INCREMENT," +
                "name VARCHAR(50) NOT NULL," +
                "email VARCHAR(50) NOT NULL UNIQUE," +
                "PRIMARY KEY (id)" +
            ")";
            stmt.executeUpdate(createCustomerTable);
            
            String createOrderTable = "CREATE TABLE Order (" +
                "id INT AUTO_INCREMENT," +
                "order_date DATE NOT NULL," +
                "amount DECIMAL(10,2) NOT NULL," +
                "customer_id INT NOT NULL," +
                "PRIMARY KEY (id)," +
                "FOREIGN KEY (customer_id) REFERENCES Customer(id)" +
            ")";
            stmt.executeUpdate(createOrderTable);
            
            // many-to-many relationship
            String createStudentTable = "CREATE TABLE Student (" +
                "id INT AUTO_INCREMENT," +
                "name VARCHAR(50) NOT NULL," +
                "email VARCHAR(50) NOT NULL UNIQUE," +
                "PRIMARY KEY (id)" +
            ")";
            stmt.executeUpdate(createStudentTable);
            
            String createCourseTable = "CREATE TABLE Course (" +
                "id INT AUTO_INCREMENT," +
                "name VARCHAR(50) NOT NULL," +
                "description VARCHAR(255) NOT NULL," +
                "PRIMARY KEY (id)" +
            ")";
            stmt.executeUpdate(createCourseTable);
            
            String createEnrollmentTable = "CREATE TABLE Enrollment (" +
                "student_id INT ," +
                "course_id INT ," +
                "PRIMARY KEY (student_id, course_id)," +
                "FOREIGN KEY (student_id) REFERENCES Student(id)," +
                "FOREIGN KEY (course_id) REFERENCES Course(id)" +
            ")";
            stmt.executeUpdate(createEnrollmentTable);
            
            System.out.println("Tables created successfully.");
            
        } catch (SQLException e) 
        {
            e.printStackTrace();
        }
        finally {
        	conn.close();
        }
    }
    
}
